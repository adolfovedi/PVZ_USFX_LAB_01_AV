// Fill out your copyright notice in the Description page of Project Settings.


#include "Suscriptor.h"

// Add default functionality here for any ISuscriptor functions that are not pure virtual.
