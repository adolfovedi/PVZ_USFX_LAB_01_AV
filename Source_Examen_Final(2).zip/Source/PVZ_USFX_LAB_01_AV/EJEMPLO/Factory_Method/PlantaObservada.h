// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Plantas.h"
#include "PlantaObservada.generated.h"

/**
 * 
 */
UCLASS()
class PVZ_USFX_LAB_01_AV_API APlantaObservada : public APlantas
{
	GENERATED_BODY()
	
};
