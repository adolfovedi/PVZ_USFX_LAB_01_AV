// Fill out your copyright notice in the Description page of Project Settings.


#include "ZombieTierraBailarin.h"

AZombieTierraBailarin::AZombieTierraBailarin()
{
	NombreZombie = "Bailarin";

	Vida = 60;
}
