// Fill out your copyright notice in the Description page of Project Settings.


#include "ZombieTierraMichaelJackson.h"

AZombieTierraMichaelJackson::AZombieTierraMichaelJackson()
{
	//--------------Declaraacion de variables------------------
	NombreZombie = "MichaelJackson";

	Vida = 80;
}
