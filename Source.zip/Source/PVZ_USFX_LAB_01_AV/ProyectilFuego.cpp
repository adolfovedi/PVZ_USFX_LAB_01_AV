// Fill out your copyright notice in the Description page of Project Settings.


#include "ProyectilFuego.h"

AProyectilFuego::AProyectilFuego()
{
	static ConstructorHelpers::FObjectFinder<UStaticMesh> FuegoMesh(TEXT("StaticMesh'/Game/StarterContent/Shapes/Shape_Torus.Shape_Torus'"));

	/*MeshBala->SetStaticMesh(FuegoMesh.Object);*/
}
