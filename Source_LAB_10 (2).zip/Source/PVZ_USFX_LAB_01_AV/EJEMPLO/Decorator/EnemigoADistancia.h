// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "DecoratorPlantas.h"
#include "EnemigoADistancia.generated.h"

/**
 * 
 */
UCLASS()
class PVZ_USFX_LAB_01_AV_API AEnemigoADistancia : public ADecoratorPlantas
{
	GENERATED_BODY()
	
};
