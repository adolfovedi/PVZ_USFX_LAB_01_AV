//// Fill out your copyright notice in the Description page of Project Settings.
//
//#pragma once
//
//#include "CoreMinimal.h"
//#include "PVZ_USFX_LAB_01_AVProjectile.h"
//#include "ProyectilFuego.generated.h"
//
///**
// * 
// */
//UCLASS()
//class PVZ_USFX_LAB_01_AV_API AProyectilFuego : public APVZ_USFX_LAB_01_AVProjectile
//{
//	GENERATED_BODY()
//public:
//	AProyectilFuego();
//	
//};
