// Copyright Epic Games, Inc. All Rights Reserved.

#include "PVZ_USFX_LAB_01_AV.h"
#include "Modules/ModuleManager.h"

IMPLEMENT_PRIMARY_GAME_MODULE( FDefaultGameModuleImpl, PVZ_USFX_LAB_01_AV, "PVZ_USFX_LAB_01_AV" );

DEFINE_LOG_CATEGORY(LogPVZ_USFX_LAB_01_AV)
 