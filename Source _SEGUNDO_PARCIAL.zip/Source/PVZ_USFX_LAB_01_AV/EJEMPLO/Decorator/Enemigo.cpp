// Fill out your copyright notice in the Description page of Project Settings.


#include "Enemigo.h"

// Add default functionality here for any IEnemigo functions that are not pure virtual.
